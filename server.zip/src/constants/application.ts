export enum EApplicationEnvironment {
    PRODUCTION = 'production',
    DEVELOPMENT = 'development'
}